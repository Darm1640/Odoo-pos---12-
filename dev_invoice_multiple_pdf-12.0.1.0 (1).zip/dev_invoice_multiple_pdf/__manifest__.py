# -*- coding: utf-8 -*-
##############################################################################
#
#    OpenERP, Open Source Management Solution
#    Copyright (C) 2015 DevIntelle Consulting Service Pvt.Ltd (<http://www.devintellecs.com>).
#
#    For Module Support : devintelle@gmail.com  or Skype : devintelle
#
##############################################################################

{
    'name': 'Bulk Invoice/Bill PDF Generated',
    'version': '12.0.1.0',
    'sequence': 1,
    'category': 'Generic Modules/Accounting',
    'description':
        """
        This Module add below functionality into odoo

        1.Print multiple pdf of invoice/bill separately\n
odoo Bulk/Multiple Invoice/Bill PDF Generated 
odoo Multiple Invoice/Bill PDF Generated 
odoo Bulk Invoice PDF Generated 
odoo Bulk Bill PDF Generated 
odoo Invoice pdf generated 

    """,
    'summary': 'Odoo apps allow to Download bulk/multiple pdf of invoice/bill separately',
    'depends': ['account'],
    'data': [
        'wizard/separated_invoice_reports_view.xml'
        ],
    'demo': [],
    'test': [],
    'css': [],
    'qweb': [],
    'js': [],
    'images': ['images/main_screenshot.png'],
    'installable': True,
    'application': True,
    'auto_install': False,
    
    # author and support Details =============#
    'author': 'DevIntelle Consulting Service Pvt.Ltd',
    'website': 'http://www.devintellecs.com',    
    'maintainer': 'DevIntelle Consulting Service Pvt.Ltd', 
    'support': 'devintelle@gmail.com',
    'price':25.0,
    'currency':'EUR',
    'live_test_url':'https://youtu.be/mcXNlYwmUgc',
}

# vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4:
