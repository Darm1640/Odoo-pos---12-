# -*- coding: utf-8 -*-
##############################################################################
#
#    OpenERP, Open Source Management Solution
#    Copyright (C) 2015 DevIntelle Consulting Service Pvt.Ltd (<http://www.devintellecs.com>).
#
#    For Module Support : devintelle@gmail.com  or Skype : devintelle
#
##############################################################################

from odoo import models, fields, _, api
from odoo.http import request
from odoo.modules import get_module_resource
import os
import shutil
import base64
from odoo.exceptions import ValidationError


class SeparatedInvoiceReports(models.TransientModel):
    _name = "separated.invoice.report"

    @api.multi
    def print_separated_invoice_bill(self):
        active_ids = self._context.get('active_ids')
        invoice_ids = self.env['account.invoice'].browse(active_ids)
        if invoice_ids:
            if not len(invoice_ids) > 1:
                raise ValidationError(_('''Please select at least 2 records'''))
            addon_path = get_module_resource('dev_invoice_multiple_pdf')
            if addon_path:
                addon_path = addon_path + '/pdf_reports'
                if os.path.isdir(addon_path):
                    shutil.rmtree(addon_path)
                os.mkdir(addon_path) # creating directory inside the module
                counter = 1
                for invoice in invoice_ids:
                    if invoice.number:
                        invoice_name = invoice.number.replace('/', '_')
                    else:
                        invoice_name = str(counter)
                        counter += 1
                    pdf_name = invoice_name + '.pdf'
                    with open(os.path.join(addon_path, pdf_name), "wb+") as f:
                        if self.copy_type == 'invoice':
                            pdf = request.env.ref('account.account_invoices').sudo().render_qweb_pdf([invoice.id])[0]
                        else:
                            pdf = request.env.ref('account.account_invoices_without_payment').sudo().render_qweb_pdf([invoice.id])[0]
                        f.write(pdf)
                download_file = shutil.make_archive(addon_path, 'zip', addon_path) # creating zip file inside the module
                if download_file:
                    with open(download_file, 'rb') as f:
                        zip_file = f.read()
                    os.remove(download_file) # removed zip file from the module
                    shutil.rmtree(addon_path)  # removing directory which is created inside the module
                    invoice_zip_reports = base64.b64encode(zip_file)
                    wiz_id = self.create({'invoice_zip_reports': invoice_zip_reports})
                    form_id = self.env.ref('dev_invoice_multiple_pdf.form_dev_invoice_multiple_pdf_download').id
                    return {'name': 'Download Separated Multiple PDF',
                            'type': 'ir.actions.act_window',
                            'view_type': 'form',
                            'view_mode': 'form',
                            'res_model': 'separated.invoice.report',
                            'views': [(form_id, 'form')],
                            'target': 'new',
                            'res_id': wiz_id.id
                            }

    invoice_zip_reports = fields.Binary(string='PDF Reports')
    copy_type = fields.Selection(selection=[('invoice', 'Invoices'),
                                            ('invoice_no_payment', 'Invoices without Payment')], default='invoice',
                                 required=True, string='PDF Report')
    zip_name = fields.Char(string='Zip Name', default='invoice_or_bill_pdf.zip')



# vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4: